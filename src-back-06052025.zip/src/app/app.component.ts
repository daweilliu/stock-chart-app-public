import { Component } from '@angular/core';
import { StockChartComponent } from './stock-chart/stock-chart.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { OnInit } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  imports: [StockChartComponent, FormsModule, CommonModule], // ✅ this line is critical
})
export class AppComponent implements OnInit {
  range: 'ytd' | '1y' | '2y' | '5y' | '10y' | 'max' = '10y';
  title = 'Projection Master';
  symbol = 'AAPL';
  showDMark = false;
  fullName = '';
  isLoadingName = false;
  showPanel = false;
  sma1Period = 5;
  sma2Period = 21;
  sma3Period = 60;
  sma4Period = 120;
  sma5Period = 240;

  showSma1 = false;
  showSma2 = false;
  showSma3 = false;
  showSma4 = false;
  showSma5 = false;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchFullName(this.symbol);
  }

  loadSymbol() {
    this.symbol = `${this.symbol.toUpperCase().trim()}`;
    this.fetchFullName(this.symbol);
    this.range = this.range; // force input change detection for range too
  }

  setRange(value: 'ytd' | '1y' | '2y' | '5y') {
    this.range = value;
  }

  onRangeChange() {
    this.range = this.range;
    this.fetchFullName(this.symbol);
  }

  getDisplayLabel(range: string): string {
    let rangeLabel = '';
    switch (range) {
      case 'ytd':
        rangeLabel = 'Year To Date';
        break;
      case '1y':
        rangeLabel = '1 Year';
        break;
      case '2y':
        rangeLabel = '2 Years';
        break;
      case '5y':
        rangeLabel = '5 Years';
        break;
      case '10y':
        rangeLabel = '10 Years';
        break;
      case 'max':
        rangeLabel = 'Max';
        break;
      default:
        rangeLabel = '';
    }
    return `${this.fullName} (${rangeLabel})`;
  }

  fullNameError = '';

  fetchFullName(symbol: string) {
    this.isLoadingName = true;
    this.fullNameError = '';
    const apiKey = '660eb09d9dbb4c20a9a8ac1160837d22';
    const url = `https://api.twelvedata.com/symbol_search?symbol=${symbol}&apikey=${apiKey}`;
    this.http.get<any>(url).subscribe(
      (res) => {
        if (res && res.data && res.data.length > 0) {
          this.fullName = res.data[0].instrument_name;
        } else {
          this.fullName = symbol.toUpperCase();
          this.fullNameError = 'Symbol not found.';
        }
        this.isLoadingName = false;
      },
      (error) => {
        this.fullName = symbol.toUpperCase();
        this.fullNameError = 'Error fetching symbol name.';
        this.isLoadingName = false;
      }
    );
  }
}

// --- File: src/app/stock-chart/stock-chart.component.ts ---
import {
  Component,
  Input,
  AfterViewInit,
  ElementRef,
  ViewChild,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import {
  createChart,
  IChartApi,
  CandlestickData,
  Time,
  LineData,
} from 'lightweight-charts';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

interface IchimokuData {
  time: string;
  tenkanSen: number | null;
  kijunSen: number | null;
  senkouSpanA: number | null;
  senkouSpanB: number | null;
  chikouSpan: number | null;
}

@Component({
  selector: 'app-stock-chart',
  templateUrl: './stock-chart.component.html',
  styleUrls: ['./stock-chart.component.css'],
  standalone: true,
  imports: [CommonModule],
})
export class StockChartComponent implements AfterViewInit, OnChanges {
  @Input() symbol: string = 'AAPL';
  @Input() range: 'ytd' | '1y' | '2y' | '5y' | '10y' | 'max' = '10y';
  @Input() showDMark: boolean = true;
  @ViewChild('chartContainer', { static: true }) chartContainer!: ElementRef;
  @Input() sma1Period: number = 5;
  @Input() showSma1: boolean = true;
  @Input() sma2Period: number = 21;
  @Input() showSma2: boolean = false;
  @Input() sma3Period: number = 60;
  @Input() showSma3: boolean = false;
  @Input() sma4Period: number = 120;
  @Input() showSma4: boolean = false;
  @Input() sma5Period: number = 240;
  @Input() showSma5: boolean = false;

  chart!: IChartApi;
  private chartReady = false;
  private candleSeries: any;
  private volumeSeries: any;

  constructor(private http: HttpClient) {}

  ngAfterViewInit(): void {
    this.initChart();
    this.chartReady = true;
    this.loadSymbolData();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.chartReady) return;
    const symbolChanged = changes['symbol'] && !changes['symbol'].firstChange;
    const rangeChanged = changes['range'] && !changes['range'].firstChange;
    const dMarkChanged =
      changes['showDMark'] && !changes['showDMark'].firstChange;

    if (symbolChanged || rangeChanged) {
      this.chart.remove();
      this.initChart();
      this.loadSymbolData();
    } else if (dMarkChanged) {
      // Only update markers, don't reload all data
      this.updateDMark();
    }
  }

  // initChart() {
  //   this.chart = createChart(this.chartContainer.nativeElement, {
  //     width: this.chartContainer.nativeElement.clientWidth,
  //     height: 750,
  //     layout: {
  //       background: { color: '#000000' },
  //       textColor: '#FFFFFF',
  //     },
  //     grid: {
  //       vertLines: { color: '#111' },
  //       horzLines: { color: '#111' },
  //     },
  //   });

  //   this.candleSeries = this.chart.addCandlestickSeries({
  //     upColor: '#1aff1a',
  //     downColor: '#ff3333',
  //     borderUpColor: '#00aa00',
  //     borderDownColor: '#cc0000',
  //     wickUpColor: '#008800',
  //     wickDownColor: '#990000',
  //   });

  //   this.volumeSeries = this.chart.addHistogramSeries({
  //     color: '#888',
  //     priceFormat: { type: 'volume' },
  //     priceScaleId: 'volume',
  //   });

  //   this.chart.priceScale('volume').applyOptions({
  //     scaleMargins: {
  //       top: 0.85,
  //       bottom: 0,
  //     },
  //   });
  // }
  initChart() {
    this.chart = createChart(this.chartContainer.nativeElement, {
      width: this.chartContainer.nativeElement.clientWidth,
      height: 750,
      layout: {
        background: { color: '#000000' },
        textColor: '#FFFFFF',
      },
      grid: {
        vertLines: { color: '#111' },
        horzLines: { color: '#111' },
      },
      rightPriceScale: {
        visible: false, // Hide the right price scale
      },
      leftPriceScale: {
        visible: true, // Show the left price scale
        borderColor: '#555',
      },
    });

    this.candleSeries = this.chart.addCandlestickSeries({
      priceScaleId: 'left', // Attach series to the left price scale
      upColor: '#1aff1a',
      downColor: '#ff3333',
      borderUpColor: '#00aa00',
      borderDownColor: '#cc0000',
      wickUpColor: '#008800',
      wickDownColor: '#990000',
    });

    this.volumeSeries = this.chart.addHistogramSeries({
      color: '#888',
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
    });

    this.chart.priceScale('volume').applyOptions({
      scaleMargins: {
        top: 0.85,
        bottom: 0,
      },
    });
  }

  loadSymbolData() {
    const apiKey = '660eb09d9dbb4c20a9a8ac1160837d22';
    const interval = '1day';
    const symbol = this.symbol.toUpperCase();
    let outputsize = '30';

    switch (this.range) {
      case '1y':
        outputsize = '365';
        break;
      case '2y':
        outputsize = '730';
        break;
      case '5y':
        outputsize = '1500';
        break;
      case '10y':
        outputsize = '3000';
        break;
      case 'max':
        outputsize = '5000'; // or the max supported by your API
        break;
    }

    const url = `https://api.twelvedata.com/time_series?symbol=${symbol}&interval=${interval}&outputsize=${outputsize}&apikey=${apiKey}&format=JSON`;

    this.http.get(url).subscribe((res: any) => {
      if (!res.values || !Array.isArray(res.values)) return;

      const reversedValues = res.values.reverse();
      const data: CandlestickData[] = reversedValues.map((bar: any) => ({
        time: bar.datetime,
        open: parseFloat(bar.open),
        high: parseFloat(bar.high),
        low: parseFloat(bar.low),
        close: parseFloat(bar.close),
      }));

      const volumeData = reversedValues.map((bar: any) => ({
        time: bar.datetime,
        value: parseFloat(bar.volume),
        color:
          parseFloat(bar.close) >= parseFloat(bar.open) ? '#1aff1a' : '#ff3333',
      }));

      this.candleSeries.setData(data);
      this.volumeSeries.setData(volumeData);

      // --- TD Sequential Marker Logic ---
      const markers: any[] = [];
      let bull: any[] = [];
      let bear: any[] = [];

      for (let i = 4; i < data.length; i++) {
        const close = data[i].close;
        const close4 = data[i - 4].close;

        if (close > close4) {
          const count = bull.length + 1;
          if (count === 9) {
            bull.push({
              time: data[i].time,
              position: 'aboveBar',
              color: 'deeppink',
              fontWeight: 'bold', // This will make the text bold
              fontSize: 20,
              //shape: 'square', // boxed "9"
              text: '9',
            });
            markers.push(...bull);
            bull = [];
          } else {
            bull.push({
              time: data[i].time,
              position: 'aboveBar',
              color: 'lightblue',
              // shape: 'circle',
              text: `${count}`,
            });
            bear = [];
          }
        } else if (close < close4) {
          const count = bear.length + 1;
          if (count === 9) {
            bear.push({
              time: data[i].time,
              position: 'belowBar',
              color: 'deeppink',
              fontWeight: 'bold', // This will make the text bold
              fontSize: 20,
              text: '9',
            });
            markers.push(...bear);
            bear = [];
          } else {
            bear.push({
              time: data[i].time,
              position: 'belowBar',
              color: 'lightblue',
              //shape: 'circle',
              text: `${count}`,
            });
            bull = [];
          }
        } else {
          bull = [];
          bear = [];
        }
      }

      markers.push(...(bull.length > 0 ? bull : bear));
      if (this.showDMark) {
        this.candleSeries.setMarkers(markers);
      } else {
        this.candleSeries.setMarkers([]); // Clear markers if unchecked
      }

      const flipFlopMarkers: any[] = [];
      const up = { direction: 'aboveBar', color: 'yellow' };
      const down = { direction: 'belowBar', color: 'cyan' };

      let mode: 'up' | 'down' = 'up'; // start with up, can also make it dynamic
      let count = 0;

      for (let i = 1; i < data.length; i++) {
        // Find starting low (first bar, or after every 9)
        if (mode === 'up') {
          if (count === 0) {
            // Find lowest close in the last N bars (you can set N=1 for strict, or longer for classic)
            // For most sequential indicators, just take current bar as new start
            count = 1;
            flipFlopMarkers.push({
              time: data[i].time,
              position: up.direction,
              color: up.color,
              text: '1',
              size: 1,
            });
          } else if (count < 9) {
            count++;
            flipFlopMarkers.push({
              time: data[i].time,
              position: up.direction,
              color: up.color,
              text: String(count),
              size: count === 9 ? 2 : 1,
              fontWeight: count === 9 ? 'bold' : undefined,
            });
            if (count === 9) {
              // Overlay 9 above and 1 below at the same bar
              flipFlopMarkers.push({
                time: data[i].time,
                position: down.direction,
                color: down.color,
                text: '1',
                size: 1,
              });
              mode = 'down';
              count = 1; // Start new count for down direction
            }
          }
        } else if (mode === 'down') {
          if (count < 9) {
            // Note: After a '9', we already drew '1' below, so continue from 2
            if (count !== 1) {
              flipFlopMarkers.push({
                time: data[i].time,
                position: down.direction,
                color: down.color,
                text: String(count),
                size: count === 9 ? 2 : 1,
                fontWeight: count === 9 ? 'bold' : undefined,
              });
            }
            count++;
            if (count > 9) {
              // Overlay 9 below and 1 above at the same bar
              flipFlopMarkers.push({
                time: data[i].time,
                position: up.direction,
                color: up.color,
                text: '1',
                size: 1,
              });
              mode = 'up';
              count = 1;
            }
          }
        }
      }

      // Add this after your TD9 markers, with a dedicated series as before:
      const flipFlopSeries = this.chart.addLineSeries({
        color: 'rgba(0,0,0,0)',
      }); // transparent line
      flipFlopSeries.setData(
        data.map((d) => ({ time: d.time, value: d.close }))
      );
      flipFlopSeries.setMarkers(flipFlopMarkers);

      if (this.showSma1) {
        const smaData = this.calculateSMA(data, this.sma1Period);
        const smaSeries = this.chart.addLineSeries({
          color: 'orange',
          lineWidth: 2,
        });
        smaSeries.setData(smaData);
      }
      if (this.showSma2) {
        const smaData = this.calculateSMA(data, this.sma2Period);
        const smaSeries = this.chart.addLineSeries({
          color: 'blue',
          lineWidth: 2,
        });
        smaSeries.setData(smaData);
      }
      if (this.showSma3) {
        const smaData = this.calculateSMA(data, this.sma3Period);
        const smaSeries = this.chart.addLineSeries({
          color: 'green',
          lineWidth: 2,
        });
        smaSeries.setData(smaData);
      }
      if (this.showSma4) {
        const smaData = this.calculateSMA(data, this.sma4Period);
        const smaSeries = this.chart.addLineSeries({
          color: 'red',
          lineWidth: 2,
        });
        smaSeries.setData(smaData);
      }
      if (this.showSma5) {
        const smaData = this.calculateSMA(data, this.sma5Period);
        const smaSeries = this.chart.addLineSeries({
          color: 'purple',
          lineWidth: 2,
        });
        smaSeries.setData(smaData);
      }
    });
  }

  calculateSMA(data: CandlestickData[], period: number): LineData[] {
    const result: { time: Time; value: number }[] = [];
    for (let i = period - 1; i < data.length; i++) {
      const slice = data.slice(i - period + 1, i + 1);
      const avg = slice.reduce((sum, bar) => sum + bar.close, 0) / period;
      result.push({ time: data[i].time, value: parseFloat(avg.toFixed(2)) });
    }
    return result;
  }

  updateDMark() {
    // You need to store the last loaded markers and data
    // For simplicity, just reload all data (or optimize as needed)
    this.loadSymbolData();
  }
}
